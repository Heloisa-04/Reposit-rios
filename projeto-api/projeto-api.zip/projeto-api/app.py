from flask import Flask, request, jsonify
import csv
import os

clientes_file = 'clientes.csv'
produtos_file = 'produtos.csv'
ordens_file = 'ordens.csv'

app = Flask(__name__)


#---CLIENTES-----#
""

#----GET_LISTAR CLIENTES
@app.route('/clientes', methods=['GET'])
def get_clientes():
    cliente = clientes_file
    return jsonify(cliente)


#----POST_ADICIONAR UM NOVO CLIENTE
    
    
#---PUT_ATUALIZAR INFORMAÇÕES EXISTENTES 


#----------------------------------------------------#

#---PRODUTOS-----#


#----GET_LISTAR PRODUTOS
@app.route('/produtos', methods=['GET'])
def get_produtos():
    produto = produtos_file
    return jsonify(produto)


#----------------------------------------------------#


#---ORDEM DAS VENDAS-----#

#----GET_ORDEM DAS VENDAS
@app.route('/ordem_vendas', methods=['GET'])
def get_ordem_vendas():
    ordem_v = ordens_file
    return jsonify(ordem_v)



#----------------------------------------------------#












if __name__ == '__main__':
    app.run(debug=True)