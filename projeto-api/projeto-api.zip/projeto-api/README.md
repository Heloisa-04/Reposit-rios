API_Mercado

Esta é uma API RESTful para gerenciamento de um supermercado utilizando Flask. A API manipula dados armazenados em arquivos CSV e permite a realização de operações CRUD (Create, Read, Update, Delete) nos seguintes recursos:

-Clientes
-Produtos
-Ordens de Vendas