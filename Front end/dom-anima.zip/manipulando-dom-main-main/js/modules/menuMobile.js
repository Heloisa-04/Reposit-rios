export default function menuMobileInit(){
    const toggle = document.querySelector('.toggle')
    const menuList = document.querySelector('.js-list')

    if(toggle && menuList){
        function activeMenu(){
            menuList.classList.toggle('active')
            const toggleIcon = toggle.querySelector('span')
            toggleIcon.classList.toggle('active')
            toggleIcon.innerText = toggleIcon.innerText === 'menu' ? 'close' : 'menu'
        }

        toggle.addEventListener('click', activeMenu)

    }
    
}