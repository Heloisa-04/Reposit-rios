export default function tabMenuInit(){
    // faça a lógica sempre utilizando uma função para exportação
    // essa função sera inicializada no index.js
}
   